<?php
header("Content-Type: application/json");
require "config.php";

if (!isset($_FILES["video"])) {
    echo json_encode(["error" => "No video uploaded"]);
    exit;
}

// Validate file type
$allowedTypes = ["video/mp4", "video/avi", "video/mov", "video/mkv", "video/webm"];
if (!in_array($_FILES["video"]["type"], $allowedTypes)) {
    echo json_encode(["error" => "Invalid file type. Only MP4, AVI, MOV, MKV, WEBM allowed"]);
    exit;
}

// Validate file size - 50MB max
if ($_FILES["video"]["size"] > 50 * 1024 * 1024) {
    echo json_encode(["error" => "File too large. Max 50MB"]);
    exit;
}

// Safe file name
$ext = pathinfo($_FILES["video"]["name"], PATHINFO_EXTENSION);
$videoPath = "uploads/" . time() . "_video." . $ext;

// Create uploads folder
if (!is_dir("uploads")) mkdir("uploads", 0777, true);

if (!move_uploaded_file($_FILES["video"]["tmp_name"], $videoPath)) {
    echo json_encode(["error" => "Failed to save video"]);
    exit;
}

// Create frames folder
if (!is_dir("frames")) mkdir("frames", 0777, true);

// Clear old frames
array_map('unlink', glob("frames/*.jpg"));

// Extract frames
exec("ffmpeg -i " . escapeshellarg($videoPath) . " -vf fps=1/2 -vframes 6 frames/frame_%03d.jpg 2>/dev/null");

$frames = glob("frames/*.jpg");

// ========== FALLBACK IF FFMPEG NOT AVAILABLE ==========
if (empty($frames)) {
    unlink($videoPath);

    $fileSize = $_FILES["video"]["size"];
    $origName = strtolower($_FILES["video"]["name"]);

    $score = 50;
    $explanations = [];

    // File name check
    if (
        strpos($origName, "fake") !== false ||
        strpos($origName, "deepfake") !== false ||
        strpos($origName, "viral") !== false ||
        strpos($origName, "edited") !== false ||
        strpos($origName, "generated") !== false
    ) {
        $score = 85;
        $explanations[] = "🚨 ফাইলের নামে সন্দেহজনক শব্দ পাওয়া গেছে";
    } elseif ($fileSize < 500 * 1024) {
        // Less than 500KB - suspiciously small
        $score = 72;
        $explanations[] = "⚠️ ভিডিও সাইজ অনেক ছোট - সন্দেহজনক হতে পারে";
    } elseif ($fileSize > 20 * 1024 * 1024) {
        // Large file - more likely real
        $score = 35;
        $explanations[] = "✅ ভিডিও সাইজ স্বাভাবিক মনে হচ্ছে";
    } else {
        $score = 55;
        $explanations[] = "⚠️ ভিডিওটি যাচাই করা সম্পূর্ণ সম্ভব হয়নি";
    }

    $explanations[] = "📌 সার্ভারে ffmpeg নেই - frame বিশ্লেষণ সম্ভব হয়নি";
    $explanations[] = "🔍 ভিডিওটি বিশ্বস্ত সূত্রে যাচাই করুন";
    $explanations[] = "⚠️ শেয়ার করার আগে নিশ্চিত হয়ে নিন";

    echo json_encode([
        "score" => $score,
        "explanations" => $explanations
    ]);
    exit;
}

// ========== ANALYZE FRAMES WITH GEMINI ==========
$suspicious = 0;
$total = 0;
$explanations = [];

foreach ($frames as $img) {
    $total++;

    $imgData = base64_encode(file_get_contents($img));

    $data = [
        "contents" => [[
            "parts" => [
                [
                    "text" => "Analyze this video frame carefully. Is it fake, deepfake, AI-generated, or manipulated? Look for unnatural facial movements, blurry edges, lighting inconsistencies, or AI artifacts. Answer in 1-2 sentences only."
                ],
                [
                    "inline_data" => [
                        "mime_type" => "image/jpeg",
                        "data" => $imgData
                    ]
                ]
            ]
        ]],
        "generationConfig" => [
            "temperature" => 0.2,
            "maxOutputTokens" => 100
        ]
    ];

    $url = "https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=" . GEMINI_API_KEY;

    $options = [
        "http" => [
            "header"  => "Content-Type: application/json\r\n",
            "method"  => "POST",
            "content" => json_encode($data),
            "timeout" => 15
        ]
    ];

    $context = stream_context_create($options);
    $res = @file_get_contents($url, false, $context);

    if (!$res) {
        $explanations[] = "Frame $total: API response failed";
        continue;
    }

    $json = json_decode($res, true);
    $text = $json["candidates"][0]["content"]["parts"][0]["text"] ?? "Could not analyze";
    $textLower = strtolower($text);

    $explanations[] = "🎞️ Frame $total: " . $text;

    if (
        strpos($textLower, "fake") !== false ||
        strpos($textLower, "deepfake") !== false ||
        strpos($textLower, "manipulated") !== false ||
        strpos($textLower, "ai-generated") !== false ||
        strpos($textLower, "artificial") !== false ||
        strpos($textLower, "generated") !== false ||
        strpos($textLower, "unnatural") !== false
    ) {
        $suspicious++;
    }
}

// Calculate score
$score = ($total > 0) ? round(($suspicious / $total) * 100) : 50;
$score = max(10, min(95, $score));

// Summary
if ($score > 70) {
    array_unshift($explanations, "🚨 " . $suspicious . "/" . $total . " ফ্রেমে সন্দেহজনক কনটেন্ট পাওয়া গেছে");
} elseif ($score > 40) {
    array_unshift($explanations, "⚠️ " . $suspicious . "/" . $total . " ফ্রেম সন্দেহজনক - আরও যাচাই করুন");
} else {
    array_unshift($explanations, "✅ " . $suspicious . "/" . $total . " ফ্রেম সন্দেহজনক - তুলনামূলক স্বাভাবিক");
}

// Cleanup
unlink($videoPath);
array_map('unlink', glob("frames/*.jpg"));

echo json_encode([
    "score" => $score,
    "explanations" => $explanations
]);
?>